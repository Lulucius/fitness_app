from fitness_analyzer import analyze_exercise

analyze_exercise('bicep_curl', 'bicep_curl.mp4')